﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactAPI.Domain
{
    public class ContactDbContext : DbContext
    {
        public ContactDbContext(string v) : base("ContactDB")
        {

        }
        public DbSet<Contact> Contact { get; set; }
        
    }
}
