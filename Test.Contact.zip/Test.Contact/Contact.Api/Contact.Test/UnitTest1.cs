using Contact.Infrastructure.Domain;
using NUnit.Framework;

namespace Contact.Test
{
    public class Tests
    {
        Contact.Domain.Contact Contact;
        public  Tests(IContact contact)
        {
            Contact = contact;
        }
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}