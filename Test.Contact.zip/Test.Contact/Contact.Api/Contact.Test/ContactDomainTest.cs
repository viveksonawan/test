﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace Contact.Test
{
    public class ContactDomainTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}
