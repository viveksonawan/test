﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContactAPI.Domain;
using Contact.Repository;
using System.Net.Http;
using System.Net;
using System.Web;
using System.Net.Http.Formatting;

namespace ContactAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CotactController : ControllerBase
    {
        private IUnitOfWork unitOfWork;
        public CotactController(IUnitOfWork unitofwork)
        {
            unitOfWork = unitofwork;
        }

        [HttpGet]
        public IEnumerable<ContactAPI.Domain.Contact> Get()
        {
            return unitOfWork.Contact.GetAll();
       

        }
        [HttpGet("{id}")]
        public ContactAPI.Domain.Contact Get(int id)
        {

            return unitOfWork.Contact.Get(id);
        
        }
        [HttpPatch]
        public HttpResponseMessage Update([FromBody] ContactAPI.Domain.Contact contact)
        {
            HttpResponseMessage result;
            if (contact == null)
            {
                result = new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
            var oldcontact = unitOfWork.Contact.Get(contact.ID);
            if (oldcontact == null)
            {
                result = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            else
            {
                unitOfWork.Contact.Delete(contact.ID);
                unitOfWork.Contact.Add(contact);
                unitOfWork.Complete();
                result = new HttpResponseMessage(HttpStatusCode.OK);
            }
            return result;
        }
        [HttpPost]
        public HttpResponseMessage Post([FromBody] ContactAPI.Domain.Contact contact)
        {
            int returnval = 0;
            HttpResponseMessage result;
            returnval = unitOfWork.Contact.Add(contact);
            unitOfWork.Complete();
            if (returnval == 1)
            {

                 result = new HttpResponseMessage(HttpStatusCode.Created);
            }
            else
            {
                result = new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
            return result;
        }

    }
    }
