﻿using Contact.Infrastructure.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContactAPI.Domain;

namespace Contact.Repository
{
   
    public interface IContactRepository : IGenericRepository<ContactAPI.Domain.Contact>
    {
    }
}
