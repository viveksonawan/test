﻿using ContactAPI.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly ContactDbContext contactStore;

        public ContactRepository(ContactDbContext context)
        {
            contactStore = context;
        }
        public int Add(ContactAPI.Domain.Contact  entity)
        {
            contactStore.Contact.Add(entity);
            return 1;
        }

        public int Delete(int id)
        {
            var catalogue = contactStore.Contact.Find(id);
            contactStore.Contact.Remove(catalogue);
            return 1;
        }

        public ContactAPI.Domain.Contact Get(int id)
        {
            return contactStore.Contact.Find(id);
        }

        public IEnumerable<ContactAPI.Domain.Contact> GetAll()
        {
            return contactStore.Contact.AsEnumerable<ContactAPI.Domain.Contact>();
        }

        public int Update(ContactAPI.Domain.Contact entity)
        {
            var contacts = contactStore.Contact.Find(entity);
            this.contactStore.Entry(contacts).CurrentValues.SetValues(entity);
            return 1;
        }
    }
}
