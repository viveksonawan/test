﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        IContactRepository Contact { get; }
        int Complete();       
    }
}
