﻿using ContactAPI.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ContactDbContext contactStore;
        public IContactRepository Contact { get; }

        public UnitOfWork(ContactDbContext contactStoreDbContext,
            IContactRepository contactRepository
           )
        {
            this.contactStore = contactStoreDbContext;
            this.Contact = contactRepository;
          
        }

        public int Complete()
        {
            return contactStore.SaveChanges();
        }

        public void Dispose(bool disposing)
        {
            if (disposing)
            {
                contactStore.Dispose();
            }
        }

        public void Dispose()
        {
            contactStore.Dispose();
        }
    }
}
