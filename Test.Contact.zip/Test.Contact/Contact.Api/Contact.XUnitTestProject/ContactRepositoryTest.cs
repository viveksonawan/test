//using Contact.Infrastructure.Domain;
using System;
using Xunit;
using ContactAPI.Domain;
using Contact.Repository;
using Moq;
using Contact.Infrastructure.Domain;
using System.Data.Entity;
using Microsoft.AspNetCore.Http;
using Ninject;

using System.Collections.Generic;

namespace Contact.XUnitTestProject
{

    public class ContactRepositoryTest
    {
        [Fact]
        public void ContactRepositoryMock_Get()
        {
           
            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IContact>().To<ContactAPI.Domain.Contact>();
            IContact contact = ninjectKernel.Get<IContact>();
            contact.FirstName = "test";


            Mock<IContactRepository> ContactRepositoryMock = new Mock<IContactRepository>();
            ContactRepositoryMock.Setup(x => x.Get(0)).Returns((ContactAPI.Domain.Contact)contact);         

            var result = ContactRepositoryMock.Object.Get(0); 
            Assert.Equal(result.FirstName, contact.FirstName );

        }
        [Fact]
        public void ContactRepositoryMock_Add()
        {
            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IContact>().To<ContactAPI.Domain.Contact>();
            IContact contact = ninjectKernel.Get<IContact>();
            contact.FirstName = "test";


            Mock<IContactRepository> ContactRepositoryMock = new Mock<IContactRepository>();
            ContactRepositoryMock.Setup(x => x.Add((ContactAPI.Domain.Contact)contact)).Returns(1);
            var result = ContactRepositoryMock.Object.Add((ContactAPI.Domain.Contact)contact);


            Assert.True(result.Equals(1),"1");


        }
        [Fact]
        public void ContactRepositoryMock_Delete()
        {
            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IContact>().To<ContactAPI.Domain.Contact>();
            IContact contact = ninjectKernel.Get<IContact>();
            contact.FirstName = "test";

          
            Mock<IContactRepository> ContactRepositoryMock = new Mock<IContactRepository>();
            ContactRepositoryMock.Setup(x => x.Delete(1)).Returns(1);
            var result = ContactRepositoryMock.Object.Add((ContactAPI.Domain.Contact)contact);


            Assert.True(result.Equals(1), "1");


        }
    }
}
