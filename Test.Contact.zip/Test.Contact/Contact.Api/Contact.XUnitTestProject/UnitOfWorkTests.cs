﻿using Contact.Infrastructure.Domain;
using Contact.Repository;
using Moq;
using Ninject;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Contact.XUnitTestProject
{
    public class UnitOfWorkTests
    {
        [Fact]
        public void UnitOfWork_Complete()
        {

            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IContact>().To<ContactAPI.Domain.Contact>();
            IContact contact = ninjectKernel.Get<IContact>();
            contact.FirstName = "test";


            Mock<IUnitOfWork> UnitOfWorkMock = new Mock<IUnitOfWork>();
            UnitOfWorkMock.Setup(x => x.Complete()).Returns(1) ;

            var result = UnitOfWorkMock.Object.Complete();
            Assert.True(result.Equals(1), "1");

        }
        [Fact]
        public void UnitOfWork_Dispose()
        {

            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IUnitOfWork>().To<UnitOfWork>();
            IUnitOfWork unitOfWork = ninjectKernel.Get<IUnitOfWork>();
           


            Mock<IUnitOfWork> UnitOfWorkMock = new Mock<IUnitOfWork>();
            UnitOfWorkMock.Setup(x => x.Dispose()).Verifiable() ;

            UnitOfWorkMock.Object.Dispose();

        
        

        }
    }
}
