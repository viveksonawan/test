﻿using Contact.Infrastructure.Domain;
using Contact.Repository;
using Moq;
using Ninject;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Contact.XUnitTestProject
{
    public class ContactModelTest
    {
        [Fact]
        public void ContactRepositoryMock_Get()
        {

            IKernel ninjectKernel = new StandardKernel();
            ninjectKernel.Bind<IContact>().To<ContactAPI.Domain.Contact>();
            IContact contact = ninjectKernel.Get<IContact>();
            contact.FirstName = "FirstName";
            contact.LastName = "LastName";
            contact.ID = 1;
            contact.phone = "1234";
            contact.IsActive = true; 
            
            Assert.Equal("FirstName", contact.FirstName);
            Assert.Equal("LastName", contact.LastName);
            Assert.Equal(1, contact.ID);
            Assert.Equal("1234", contact.phone);
            Assert.True(contact.IsActive);

        }
    }
}
